TD3 - Exercice 1 - Solution SIMPLE

Cette version retire volontairement :
- Google Fonts
- Material Symbols
- preconnect
- sticky header
- z-index
- calc()
- flex-grow
- sélecteurs inutilement compliqués

Elle utilise seulement :
- HTML déjà connu : header, nav, a, main, div, img, h2, p
- CSS déjà connu : couleur, width, margin, padding, font-size...
- TD3 :
  * :hover
  * position: relative
  * position: absolute
  * display: flex
  * justify-content
  * align-items
  * flex-wrap
  * gap
  * opacity
  * transition

La flèche de téléchargement est simplement le caractère Unicode : ⬇
Les statistiques utilisent aussi des caractères simples : 👍 et 👁
Donc AUCUNE bibliothèque externe n'est nécessaire.

CARTE DE LA SOLUTION
1. header { display:flex } -> organise logo + nav
2. nav { display:flex } -> organise les liens
3. main { display:flex; flex-wrap:wrap } -> organise les tuiles
4. .tile { position:relative } -> repère pour l'overlay
5. .overlay { position:absolute; opacity:0 } -> posé sur la tuile et caché
6. .tile:hover > .overlay { opacity:1 } -> visible au survol
7. transition -> apparition douce
